import main
import character
import weapon
import items
import world
import button
#print(main.__doc__)
#print(character.__doc__)
#print(weapon.Weapon.__doc__)
#print(weapon.Arrow.__doc__)
#print(weapon.Fireball.__doc__)
#print(items.__doc__)
# print(world.__doc__)
print(button.__doc__)